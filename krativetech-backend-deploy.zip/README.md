Krative Tech Backend - Express (Render ready)

Deployment steps (Render):
1. Push this repo to GitHub or upload folder to Render (manual deploy).
2. Create a new Web Service on Render and point to this repository/folder.
3. Set environment variables in Render dashboard (Environment):
   - PORT=10000
   - FRONTEND_ORIGIN=*   (or set to your frontend URL)
   - EMAIL_USER=krativetech5@gmail.com
   - EMAIL_PASS=<Gmail app password>
   - SMTP_HOST=smtp.gmail.com
   - SMTP_PORT=587
4. Build command: npm install
5. Start command: npm start
6. Test health: GET https://<your-render-url>/api/health
7. Test contact by POSTing JSON to /api/contact