require('dotenv').config();
const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const nodemailer = require('nodemailer');

const app = express();
const port = process.env.PORT || 10000;

app.use(express.json());
// CORS: allow any origin (WORK ON ANY)
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || '*' }));

const limiter = rateLimit({ windowMs: 60 * 1000, max: 8, message: { error: 'Too many requests, try again later.' } });
app.use('/api/', limiter);

function validatePayload(body) {
  const { name, email, message } = body;
  if (!name || !email || !message) return false;
  const re = /\S+@\S+\.\S+/;
  if (!re.test(email)) return false;
  if (String(message).trim().length < 5) return false;
  return true;
}

async function createTransport() {
  // Using SMTP (Gmail app password recommended)
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: Number(process.env.SMTP_PORT) || 587,
    secure: false,
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    }
  });
}

app.post('/api/contact', async (req, res) => {
  try {
    if (!validatePayload(req.body)) return res.status(400).json({ error: 'Invalid form data.' });
    const { name, email, message, phone } = req.body;
    const transport = await createTransport();
    const mailOptions = {
      from: `"Krative Tech Website" <${process.env.EMAIL_USER}>`,
      to: process.env.EMAIL_USER || 'krativetech5@gmail.com',
      subject: `Website contact from ${name}`,
      text: `Name: ${name}\nEmail: ${email}\nPhone: ${phone || 'N/A'}\n\nMessage:\n${message}`,
      html: `<p><strong>Name:</strong> ${name}</p><p><strong>Email:</strong> ${email}</p><p><strong>Phone:</strong> ${phone || 'N/A'}</p><p><strong>Message:</strong></p><p>${message.replace(/\n/g,'<br/>')}</p>`
    };
    await transport.sendMail(mailOptions);
    return res.json({ success: true, message: 'Message sent.' });
  } catch (err) {
    console.error('Contact error:', err);
    return res.status(500).json({ error: 'Failed to send message.' });
  }
});

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

app.listen(port, () => console.log(`Server listening on port ${port}`));